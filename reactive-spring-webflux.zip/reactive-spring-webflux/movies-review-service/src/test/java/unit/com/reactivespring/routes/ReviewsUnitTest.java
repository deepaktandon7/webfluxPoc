package com.reactivespring.routes;

public class ReviewsUnitTest {
}
