package com.learnreactiveprogramming.service;

import lombok.var;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class FluxAndMonoGeneratorService {

    public Flux<String> namesFlux(){
        return Flux.fromIterable(Arrays.asList("Deepak", "Worakorn", "Anshul")).log(); //can call db
    }

    public Flux<String> namesFlux_map(){
        return Flux.fromIterable(Arrays.asList("Deepak", "Worakorn", "Anshul"))
                .map(String::toUpperCase)
                .log(); //can call db
    }
    public Flux<String> namesFlux_map_immutability(){
        var f= Flux.fromIterable(Arrays.asList("Deepak", "Worakorn", "Anshul"));
                f.map(String::toUpperCase);
        return f; //not affected by line 23

    }
    public Flux<String> namesFlux_flatmap(){
        return Flux.fromIterable(Arrays.asList("Deepak", "Worakorn", "Anshul"))
                .map(String::toUpperCase)
                .flatMap(s->splitString(s))
                .log(); //can call db
    }
    private Flux<String> splitString(String s){
        var chars=s.split("");
        return  Flux.fromArray(chars);
    }
    public Flux<String> namesFlux_flatmap_async(){
        return Flux.fromIterable(Arrays.asList("Deepak", "Worakorn", "Anshul"))
                .map(String::toUpperCase)
                //.flatMap(s->splitString_delay(s))
                .concatMap(s->splitString_delay(s))
                .log(); //can call db
    }
    public Flux<String> namesFlux_flatmap_transform(){

        Function<Flux<String>,Flux<String>> filterMap= name-> name.map(String::toUpperCase)
                .filter(s->s.length()>1);
        return Flux.fromIterable(Arrays.asList("Deepak", "Worakorn", "Anshul"))
                .transform(filterMap).log(); //can call db
    }
    private Flux<String> splitString_delay(String s){
        var chars=s.split("");
        return  Flux.fromArray(chars)
                .delayElements(Duration.ofMillis(1000));
    }

    public Mono<String> namesMono(){
        return Mono.just("Deepak").log(); //can call db
    }
    public Mono<String> namesMono_map(){
        return Mono.just("Deepak")
                .map(String::toUpperCase)
                .log(); //can call db
    }
    public Mono<List<String>> namesMono_flatMap(){
        return Mono.just("Deepak")
                .map(String::toUpperCase)
                .flatMap(this::splitStringMono)
                .log(); //can call db
    }
    public Flux<String> namesMono_flatMapMany(){
        return Mono.just("Deepak")
                .map(String::toUpperCase)
                .flatMapMany(this::splitString)
                .log(); //can call db
    }
    private Mono<List<String>> splitStringMono(String str){
        var chars=str.split("");
        var charList=Arrays.asList(chars);
        return Mono.just(charList);
    }
    public static  void  main(String[] args){
        FluxAndMonoGeneratorService fluxAndMonoGeneratorService = new FluxAndMonoGeneratorService();
        fluxAndMonoGeneratorService.namesFlux().subscribe(name->
        {
            System.out.println("name is = "+name);
        }
        );
        fluxAndMonoGeneratorService.namesMono().subscribe(name->
                {
                    System.out.println("Mono name is = "+name);
                }
        );
        fluxAndMonoGeneratorService.namesFlux_flatmap().subscribe(name->
                {
                    System.out.println("flatmap name is = "+name);
                }
        );
        fluxAndMonoGeneratorService.namesFlux_flatmap_async().subscribe(name->
                {
                    System.out.println("delay flatmap name is = "+name);
                }
        );
        fluxAndMonoGeneratorService.namesMono_map().subscribe(name->
                {
                    System.out.println("Mono name is = "+name);
                }
        );
        fluxAndMonoGeneratorService.namesMono_flatMap().subscribe(name->
                {
                    System.out.println("Mono name is = "+name);
                }
        );
    }
}
