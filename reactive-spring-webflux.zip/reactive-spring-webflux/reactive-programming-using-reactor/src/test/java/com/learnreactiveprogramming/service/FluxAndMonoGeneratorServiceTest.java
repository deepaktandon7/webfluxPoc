package com.learnreactiveprogramming.service;

import lombok.var;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.*;

class FluxAndMonoGeneratorServiceTest {
    FluxAndMonoGeneratorService fluxAndMonoGeneratorService = new FluxAndMonoGeneratorService();
    @Test
    void namesFlux(){

        var f=fluxAndMonoGeneratorService.namesFlux();
        StepVerifier.create(f)
                .expectNext("Deepak", "Worakorn", "Anshul")
                        .verifyComplete();
    }
    @Test
    void namesFlux1(){

        var f=fluxAndMonoGeneratorService.namesFlux();
        StepVerifier.create(f)
                .expectNext("Deepak")
                .expectNextCount(2)
                .verifyComplete();
    }
    @Test
    void namesFlux_flatmap_async(){

        var f=fluxAndMonoGeneratorService.namesFlux_flatmap_async();
        StepVerifier.create(f)
                .expectNextCount(20)
                .verifyComplete();
    }
}